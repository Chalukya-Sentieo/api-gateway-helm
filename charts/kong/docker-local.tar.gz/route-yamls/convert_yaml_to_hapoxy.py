import yaml

HTTPS_ONLY = True
DOMAIN_PREFIX = ''

default = '''
global
    stats socket /var/run/api.sock user root group root mode 660 level admin expose-fd listeners
    log stdout format raw local0 info

defaults
    mode http
    timeout client 10s
    timeout connect 5s
    timeout server 10s
    timeout http-request 10s
    log global

frontend rest
    bind *:80'''

if HTTPS_ONLY:
    default += '''
    bind *:443 ssl crt /etc/haproxy/certs/sentieo.com.pem
    redirect scheme https if !{ ssl_fc }
'''

append = '''

frontend stats
    bind                0.0.0.0:8888
    mode            	http
    stats           	enable
    option          	httplog
    stats           	show-legends
    stats          		uri /haproxy
    stats           	realm Haproxy\ Statistics
    stats           	refresh 5s
'''

domainMap = {
    'search' : {
        'port': 8080,
        'dns': [
            'dev-search',
            'user-dev-search'
        ]
    },
    'collab' : {
        'port': 8200,
        'dns': [
            'user-dev-rms',
            'user-dev-settings'
        ]
    },
    'finance' : {
        'port': 8080,
        'dns': [
            'dev-finance',
            'user-dev-finance'
        ]
    },
    'scraping' : {
        'port': 8080,
        'dns': [
            'dev-scraping'
        ]
    },
    'graph' : {
        'port': 8080,
        'dns': [
            'dev-graph',
            'user-dev-graph'
        ]
    },
    'gateway' : {
        'port': 8080,
        'dns': [
            'dev-gateway'
        ]
    },
    'user' : {
        'port': 5000,
        'dns': [
            'user-dev-mgmt'
        ]
    },
    # 'web' : {
    #     'port': 80,
    #     'dns': [
    #         'dev'
    #     ]
    # },
}

haproxyCfg = default
servers = ''

for file, desc in domainMap.items():
    with open(f'routes/{file}.yaml', 'r') as f:
        apis = yaml.full_load(f)
        for dns in desc['dns']:
            #LEVEL 2
            haproxyCfg += f'''
    acl {file}_req hdr(host) -i {DOMAIN_PREFIX}{dns}.sentieo.com'''
        if apis:
            for api in apis['apis']:
                haproxyCfg += f'''
    acl {file}_req path_beg -i /api/{api}'''

        #LEVEL 1
        servers += f'''
backend sentieo{file}-srv
    server {file}-server sentieo{file}:{desc['port']} check
'''
        #LEVEL 1
        haproxyCfg += f'''
    use_backend sentieo{file}-srv if {file}_req
'''
        f.close()

# TODO uncomment once web is ready
# haproxyCfg += '''
#     default_backend sentieoweb-srv
# '''
haproxyCfg += servers
haproxyCfg += append
with open('haproxy.cfg', 'w') as f:
    f.write(haproxyCfg)
    f.close()

