import yaml
from glob import glob

routesYamls = glob('*/*.yaml')

for routeYaml in routesYamls:
    with open(routeYaml, 'r+') as f:
        apis = yaml.full_load(f)
        if apis:
            for route, desc in apis['apis'].items():
                if 'request_method' in desc and type(desc['request_method']).__name__ != 'list':
                    print (route, desc)
                    desc['request_method'] = [desc['request_method']]
                    print (route, desc)
                    apis['apis'][route] = desc
            f.seek(0)
            yaml.dump(apis, f, default_flow_style=False, indent=2)
        f.close()
